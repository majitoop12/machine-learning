# 🍓 NutriFrutas Pro - Visualizador Nutricional Inteligente

Aplicación web moderna, interactiva y de alto rendimiento diseñada para consultar, comparar y calcular los valores nutricionales de frutas utilizando la API de **Fruityvice** (`https://www.fruityvice.com`).

---

## 🌟 Características Principales

1. **Catálogo y Explorador de Frutas:**
   - Visualización de frutas con diseño de tarjetas *glassmorphic* y paletas de colores temáticas.
   - Búsqueda bilingüe instantánea (español e inglés: ej. *"Fresa"* o *"Strawberry"*, *"Plátano"* o *"Banana"*).
   - Filtros inteligentes por perfil nutricional:
     - 🔥 Bajas en calorías (<50 kcal)
     - 🚫 Bajas en azúcar (<7g)
     - 💪 Ricas en proteína
     - ⚡ Energéticas / Altas en carbohidratos
     - 🥑 Keto-Friendly
   - Filtro por familia botánica (Rosaceae, Rutaceae, Musaceae, etc.).
   - Ordenación dinámica por calorías, azúcares, carbohidratos, proteínas y orden alfabético.

2. **Ficha Nutricional Pro (Modal Interactivo):**
   - Etiqueta nutricional de estándar alimentario por 100g.
   - Gráfico de dona vectorial SVG interactivo con desglose de azúcares, carbohidratos complejos, proteínas y grasas.
   - Medidor semáforo de densidad calórica.
   - Clasificación taxonómica (Familia, Orden, Género) y lista de beneficios clave para la salud.

3. **Comparador Frente a Frente (Fruit Versus / Duelo Nutricional):**
   - Selección dinámica de dos frutas con botón de intercambio rápido.
   - Gráficos comparativos de barras horizontales con indicador de ganador en cada categoría.
   - Veredicto dietético inteligente generado automáticamente según los objetivos (pérdida de peso, energía, recuperación muscular).

4. **Calculadora de Porciones y Creador de Ensaladas / Batidos:**
   - Permite combinar diferentes frutas y especificar los gramos exactos de cada una.
   - Sumatoria en tiempo real de calorías totales, peso neto y macronutrientes.
   - Gráfico de macronutrientes acumulados del tazón.
   - Recetas sugeridas predefinidas (Pre-Entreno, Detox Antioxidante, Mix Hidratante Ligero, Explosión Tropical).
   - Botón para copiar el resumen nutricional de la receta al portapapeles.

5. **Modo Claro / Modo Oscuro:**
   - Soporte para cambio de tema con detección automática de preferencias del sistema y almacenamiento en `localStorage`.

6. **Conectividad Resiliente con Fruityvice:**
   - Peticiones asíncronas en vivo a `https://www.fruityvice.com/api/fruit/all`.
   - Sistema de tolerancia a fallos con proxy CORS y base de datos local enriquecida para garantizar funcionamiento 100% offline o sin restricciones de red.

---

## 🚀 Cómo Ejecutar la Aplicación

Puedes ejecutar la aplicación fácilmente de varias formas:

### Opción 1: Servidor Node.js Nativo (Recomendado - Sin Descargas)
Abre PowerShell o tu terminal en la carpeta del proyecto y ejecuta:
```bash
node server.js
```
Luego visita en tu navegador:
- [http://localhost:8000](http://localhost:8000) o [http://127.0.0.1:8000](http://127.0.0.1:8000)

### Opción 2: Con Python
```bash
python -m http.server 8000
```
Luego visita `http://127.0.0.1:8000` o `http://localhost:8000`.

### Opción 3: Extensión Live Server de VS Code / Antigravity IDE
Haz clic derecho en `index.html` y selecciona **"Open with Live Server"**.

---

## 📂 Estructura del Proyecto

```
nutrifrutas-web/
│
├── index.html              # Estructura semántica, accesibilidad y layout
├── README.md               # Documentación completa del proyecto
├── css/
│   ├── style.css           # Tokens de diseño, tipografía, variables y modo oscuro/claro
│   └── components.css      # Estilos de tarjetas, modales, gráficos y vistas
└── js/
    ├── api.js              # Conector asíncrono a Fruityvice, caché y filtros
    ├── data.js             # Base de datos enriquecida bilingüe y beneficios saludables
    ├── charts.js           # Generador de gráficos SVG nativos (donas y barras)
    ├── compare.js          # Lógica del comparador versus
    ├── calculator.js       # Lógica de la calculadora de porciones y tazones
    └── app.js              # Controlador principal y eventos
```
